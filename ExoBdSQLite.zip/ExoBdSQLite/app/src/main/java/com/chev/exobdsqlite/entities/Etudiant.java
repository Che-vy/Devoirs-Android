package com.chev.exobdsqlite.entities;

public class Etudiant {

    private int age;
    private String nom, prenom;

    public Etudiant(int age, String nom, String prenom){
        this.age = age;
        this.nom = nom;
        this.prenom = prenom;
    }
}
