package com.chev.exobdsqlite.manager;

public class EtudiantManager {

    public static String nomTable = "Etudiants";
    public static String queryGetAll = "SELECT * FROM" + nomTable + ";";
}
