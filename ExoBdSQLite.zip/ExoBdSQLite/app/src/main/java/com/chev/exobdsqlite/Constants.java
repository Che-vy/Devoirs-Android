package com.chev.exobdsqlite;

public class Constants {

}
