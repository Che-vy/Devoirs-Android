package com.chev.j5exocosinus;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

public class MainActivity extends Activity {

    LinearLayout ll;
    Balle balle;
    double cosX, cosY, step;
    Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ll = findViewById(R.id.wrapper);
        DisplayMetrics metric = getResources().getDisplayMetrics();
        balle = new Balle(this, metric.widthPixels, metric.heightPixels);
        balle.setRadius(50);
        ll.addView(balle);

        handler = new Handler();
        handler.post(balle);
    }

}

class Balle extends View implements Runnable {

    double x, y, radius, dx;
    double screenWidth;
    Paint p;

    float amplitude;

    public Balle(Context context, int sWidth, int sHeight) {
        super(context);
        p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.RED);
        screenWidth = sWidth;
        Log.d("debug", "sWidth" + sWidth);
        amplitude = sHeight;
        dx = ((Math.PI/2)/ screenWidth) * 15;
    }

    public void onDraw(Canvas canvas) {
        canvas.drawCircle((float)x*15, (float)y, (float)radius, p);

    }

    @Override
    public void run() {
        invalidate();
        x += dx;
        y = Math.cos(x) * amplitude/4;
        postDelayed(this, 50);
    }
    
    public float getX() {
        return (float) x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public float getY() {
        return (float) y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setRadius(float radius) {
        this.radius = radius;
    }


}
