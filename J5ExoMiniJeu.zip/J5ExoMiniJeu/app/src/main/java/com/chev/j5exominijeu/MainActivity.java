package com.chev.j5exominijeu;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.EventListener;

public class MainActivity extends Activity implements SensorEventListener {

    Context ctx;
    LinearLayout ll;
    MonImage img1, img2;
    int sHeight, sWidth;
    Sensor sensor;
    SensorManager sManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ctx = this;
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        ll = findViewById(R.id.wrapper);
        Handler h = new Handler();
        img1 = new MonImage(this, R.drawable.winnie);
        img2 = new MonImage(this, R.drawable.nest);
        sManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        sensor = sManager.getDefaultSensor(SensorManager.SENSOR_ACCELEROMETER);


        TextView tv = findViewById(R.id.tv_temps);
        final Timer t = new Timer(tv, h);
        final Button btn_start = new Button(this);
        btn_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t.run();
                sManager.registerListener((SensorEventListener)getParent(), sensor, SensorManager.SENSOR_DELAY_NORMAL);
                btn_start.setVisibility(View.GONE);
            }
        });
        ll.addView(btn_start);
        ll.addView(img1);
        ll.addView(img2);


    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if(event.sensor == sensor) {
            if ((img1.getX() < 0) || (img1.getX() + img1.getWidth() > ll.getWidth())) {
                Log.d("debug", "img1.getWidth = " + img1.getWidth());
            } else {
                img1.setX(img1.getX() + event.values[0]);
            }
            if ((img1.getY() < 0) || (img1.getY() + img1.getHeight() > ll.getHeight())) {
                Log.d("debug", "ll.getHeight = " + ll.getHeight());
            } else {
                img1.setY(img1.getY() + event.values[1]);
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}

class Timer implements Runnable{

    TextView tv;
    Handler handler;
    int secondes = 0;

    public Timer(TextView tv, Handler handler){
        this.tv = tv;
        this.handler = handler;
    }

    @Override
    public void run() {
        secondes++;
        tv.setText("Temps écoulé: " + secondes);
        handler.postDelayed(this, 1000);
    }
}
