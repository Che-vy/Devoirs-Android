package com.chev.j5exominijeu;

import android.app.Activity;
import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HardwarePropertiesManager;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.EventListener;

public class MainActivity extends Activity implements SensorEventListener {

    Context ctx;
    LinearLayout ll, llbtn;
    RelativeLayout rl;
    MonImage img1, img2;
    int sHeight, sWidth, points;
    Sensor sensor;
    SensorManager sManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //application params
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        //data initialization
        ctx = this;
        ll = findViewById(R.id.wrapper);
        llbtn = findViewById(R.id.wrapper_btn);
        rl = findViewById(R.id.wrapper_personnages);
        final Handler h = new Handler();
        img1 = new MonImage(this, R.drawable.winnie);
        img2 = new MonImage(this, R.drawable.nest);
        img2.setLeft(300);
        img2.setTop(300);
        img1.updateCoords((int)img1.getLeft(), (int)img1.getTop());
        img2.updateCoords((int)img2.getLeft(), (int)img2.getTop());
        sManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        sensor = sManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        //start button/timer init
        TextView tv = findViewById(R.id.tv_temps);
        final Timer t = new Timer(tv, h);
        final Button btn_start = new Button(this);
        sManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME);
        btn_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                h.post(t);
                btn_start.setVisibility(View.INVISIBLE);
            }
        });

        //views to layouts
        llbtn.addView(btn_start);
        rl.addView(img2);
        rl.addView(img1);

        tv =  findViewById(R.id.tv_score);
        CollisionChecker cc = new CollisionChecker(img1, img2, tv, h);
        cc.run();

    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if(event.sensor == sensor) {
//            if ((img1.getX() < 0) || (img1.getX() + img1.getWidth() > ll.getWidth())) {
//                Log.d("debug", "img1.getWidth = " + img1.getWidth());
//            } else {
//                img1.setX(img1.getX() + event.values[0]);
//            }
//            if ((img1.getY() < 0) || (img1.getY() + img1.getHeight() > ll.getHeight())) {
//                Log.d("debug", "ll.getHeight = " + ll.getHeight());
//            } else {
//                img1.setY(img1.getY() + event.values[1]);
//            }


            img1.setX(img1.getX() - event.values[0]);
            img1.setY(img1.getY() + event.values[1]);
            img1.updateCoords((int)img1.getX(), (int)img1.getY());
            //img1.invalidate();
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}

class Timer implements Runnable{

    TextView tv;
    Handler handler;
    int secondes = 0;

    public Timer(TextView tv, Handler handler){
        this.tv = tv;
        this.handler = handler;
    }

    @Override
    public void run() {
        secondes++;
        tv.setText("Temps écoulé: " + secondes);
        handler.postDelayed(this, 1000);
    }
}

class ObjImg {
    ImageView img;
    int x1, x2, x3, x4, y1, y2, y3, y4;

    public ObjImg(ImageView img)
    {
        this.img = img;
        x1 = (int) img.getX();
        y1 = (int) img.getY();
        x2 = x1 + img.getWidth();
        y2 = y1;
        x3 = x2;
        y3 = y1 + img.getHeight();
        x4 = x1;
        y4 = y1 + img.getHeight();
    }

    public ImageView getImg() {
        return img;
    }

    public void setImg(ImageView img) {
        this.img = img;
    }

    public int getX1() {
        return x1;
    }

    public void setX1(int x1) {
        this.x1 = x1;
    }

    public int getX2() {
        return x2;
    }

    public void setX2(int x2) {
        this.x2 = x2;
    }

    public int getX3() {
        return x3;
    }

    public void setX3(int x3) {
        this.x3 = x3;
    }

    public int getX4() {
        return x4;
    }

    public void setX4(int x4) {
        this.x4 = x4;
    }

    public int getY1() {
        return y1;
    }

    public void setY1(int y1) {
        this.y1 = y1;
    }

    public int getY2() {
        return y2;
    }

    public void setY2(int y2) {
        this.y2 = y2;
    }

    public int getY3() {
        return y3;
    }

    public void setY3(int y3) {
        this.y3 = y3;
    }

    public int getY4() {
        return y4;
    }

    public void setY4(int y4) {
        this.y4 = y4;
    }
}

class CollisionChecker implements Runnable
{
    MonImage obj1, obj2;
    TextView score;
    Handler handler;
    int points;
    Context ctx;

    public CollisionChecker(MonImage obj1, MonImage obj2, TextView score, Handler handler){
        this.obj1 = obj1;
        this.obj2 = obj2;
        this.score = score;
        this.handler = handler;
    }

    @Override
    public void run() {
        Log.d("coll", "" + obj2.getX1());
        Log.d("coll", "" + obj2.getX3());
        if((obj1.getX1() > obj2.getX1() && obj1.getX1() < obj2.getX2() && obj1.getY1() > obj2.getY3())
                || (obj1.getX2() > obj2.getX1() && obj1.getX2() < obj2.getX2() && obj1.getY2() > obj2.getY3())
                || (obj1.getX3() > obj2.getX1() && obj1.getX3() < obj2.getX2() && obj1.getY3() < obj2.getY3())
                || (obj1.getX4() > obj2.getX1() && obj1.getX4() < obj2.getX2() && obj1.getY4() < obj2.getY3()))
        {
            points++;
            score.setText("Nombre de points: " + points);
        }
        handler.postDelayed(this, 100);
    }
}
