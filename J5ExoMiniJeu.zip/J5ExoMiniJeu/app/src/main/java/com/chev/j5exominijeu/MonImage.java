package com.chev.j5exominijeu;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.DisplayMetrics;
import android.widget.ImageView;

public class MonImage extends ImageView {

    Bitmap img;

    public MonImage(Context context, int imgRessource) {
        super(context);
        img = Bitmap.createBitmap(BitmapFactory.decodeResource(context.getResources(), imgRessource));
        setImageBitmap(img);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        setMeasuredDimension(metrics.widthPixels/12, metrics.heightPixels/12);
    }
}
