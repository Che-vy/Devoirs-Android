package com.chev.j5exominijeu;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.DisplayMetrics;
import android.widget.ImageView;

public class MonImage extends ImageView {

    Bitmap img;
    int x1, x2, x3, x4, y1, y2, y3, y4;

    public MonImage(Context context, int imgRessource) {
        super(context);
        img = Bitmap.createBitmap(BitmapFactory.decodeResource(context.getResources(), imgRessource));
        setImageBitmap(img);
        x1 = (int) getLeft();
        y1 = (int) getTop();
        x2 = x1 + getRight();
        y2 = y1;
        x3 = x2;
        y3 = y1 + getBottom();
        x4 = x1;
        y4 = y3;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        setMeasuredDimension(metrics.widthPixels/6, metrics.heightPixels/6);
    }

    public void updateCoords(int x, int y){
        setX1(x);
        setX2(x + getRight());
        setX3(x + getRight());
        setX4(x);
        setY1(y);
        setY2(y);
        setY3(y + getBottom());
        setY4(y + getBottom());


    }

    public int getX1() {
        return x1;
    }

    public void setX1(int x1) {
        this.x1 = x1;
    }

    public int getX2() {
        return x2;
    }

    public void setX2(int x2) {
        this.x2 = x2;
    }

    public int getX3() {
        return x3;
    }

    public void setX3(int x3) {
        this.x3 = x3;
    }

    public int getX4() {
        return x4;
    }

    public void setX4(int x4) {
        this.x4 = x4;
    }

    public int getY1() {
        return y1;
    }

    public void setY1(int y1) {
        this.y1 = y1;
    }

    public int getY2() {
        return y2;
    }

    public void setY2(int y2) {
        this.y2 = y2;
    }

    public int getY3() {
        return y3;
    }

    public void setY3(int y3) {
        this.y3 = y3;
    }

    public int getY4() {
        return y4;
    }

    public void setY4(int y4) {
        this.y4 = y4;
    }

}
